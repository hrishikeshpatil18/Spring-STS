package com.cg.dao;

import com.cg.entities.Account;
import com.cg.entities.Customer;

public interface Dao {
	
	public abstract void createCustomerDao(Customer customer);
	public abstract Account getAccount(int accountNo);
//	public abstract Account depositDao(int depositAccount);
//	public abstract Account withdrawDao(int withdrawAccount);
	public abstract void beginTransaction();
	public abstract void commitTransaction();

}
