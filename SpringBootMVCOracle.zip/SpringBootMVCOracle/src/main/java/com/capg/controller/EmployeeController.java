package com.capg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capg.beans.Employee;
import com.capg.service.IEmployeeService;

@RestController
public class EmployeeController {
	@Autowired
	IEmployeeService service;
	
	
	
	@GetMapping(path="/employee/{eid}",produces= {"Application/json"})
	public Employee getEmployeeById(@PathVariable int eid)
	{
		Employee emp=service.getEmployeeById(eid);
		return emp;
	}
	
	
	
	
	@GetMapping(path="/employees", produces="application/xml")
	public List<Employee> getAllEmployee()
	{
		return service.getAllEmployee();
	}
		
	
	@DeleteMapping(path="/employees/{eid}")
	public void deleteEmployeeById(@PathVariable int eid)
	{
		service.deleteEmployeeById(eid);;
		
	}
	

	@PostMapping(path="/employee",consumes="application/xml")
	public Employee addEmployee(@RequestBody Employee emp)
	{
		
	
		return service.addEmployee(emp);
	}
	
	
	
	@PutMapping(path="/employee",consumes="application/json")
	public Employee updateEmployee(@RequestBody Employee emp)
	{
	
		return service.updateEmployee(emp);
	}
	
	

	@GetMapping(path="/employeeSal/{salary}",produces= {"Application/json"})
	public List<Employee> getEmployeeBySalary(@PathVariable double salary)
	{
				return service.getEmployeeBySalary(salary);
		
	}
	

	@GetMapping(path="/employeeRange",produces= {"Application/json"})
	public List<Employee> getEmployeesByRange()
	{
				return service.getEmployeesByRange();
		
	}
	
	
	
	
}
