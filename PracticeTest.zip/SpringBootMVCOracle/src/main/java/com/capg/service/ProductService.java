package com.capg.service;

import java.util.List;

import com.capg.beans.Product;

public interface ProductService {

	public Product getProductById(int pid);
	public List<Product> getAllProduct();
	
	public void deleteProductById(int pid);

	public Product addProduct(Product product);
	
	public Product updateProduct(Product product);
	
	/*public List<Product> getEmployeeBySalary(double salary);
	
	public List<Product> getEmployeesByRange();*/
}
