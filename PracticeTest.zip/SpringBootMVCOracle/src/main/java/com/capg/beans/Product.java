package com.capg.beans;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.Max;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.stereotype.Component;
@Component
@Entity
public class Product {
	
	@Id
	@NotNull
	private int pId;
	
	@NotNull
	@Size(max=30, min=4)
	private String pName;
	
	@Max(value=90000)
	private double price;
	private double mNo;
	
	
	public int getpId() {
		return pId;
	}
	public void setpId(int pId) {
		this.pId = pId;
	}
	public String getpName() {
		return pName;
	}
	public void setpName(String pName) {
		this.pName = pName;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public double getmNo() {
		return mNo;
	}
	public void setmNo(double mNo) {
		this.mNo = mNo;
	}
	
	
}
