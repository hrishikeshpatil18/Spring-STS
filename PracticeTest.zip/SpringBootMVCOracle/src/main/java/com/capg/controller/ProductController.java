package com.capg.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.capg.beans.Product;
import com.capg.exception.ProductExp;
import com.capg.service.ProductService;

@RestController
public class ProductController {
	@Autowired
	ProductService service;
	
	
	
	@GetMapping(path="/employee/{eid}",produces= {"Application/json"})
	public Product getProductById(@PathVariable int eid)
	{
		Product product=service.getProductById(eid);
		return product;
	}
	
	
	@GetMapping(path="/products", produces="application/json")
	public List<Product> getAllProduct()  throws ProductExp
	{
		//return service.getAllProduct();
		List <Product> list =  service. getAllProduct();
		
		if(list.size()==0)
		{
			throw new ProductExp();
		}
		
		
		return list;
	}
		
	
	@DeleteMapping(path="/productDelete/{pid}")
	public void deleteProductById(@PathVariable int pid)
	{
		service.deleteProductById(pid);;
		
	}
	

	@PostMapping(path="/productAdd",consumes="application/json")
	public Product addProduct(@Valid @RequestBody Product product)
	{
		
	
		return service.addProduct(product);
	}
	
	
	
	@PutMapping(path="/productUpdate",consumes="application/json")
	public Product updateEmployee(@Valid @RequestBody Product product)
	{
	
		return service.updateProduct(product);
	}
	
	

	/*@GetMapping(path="/employeesalary/{salary}",produces= {"Application/json"})
	public List<Employee> getEmployeeBySalary(@PathVariable double salary) throws EmployeeExp
	{
				List <Employee> list =  service.getEmployeeBySalary(salary);
				
				if(list.size()==0)
				{
					throw new EmployeeExp();
				}
				
				
				return list;
		
	}*/
	

	/*@GetMapping(path="/employeeRange",produces= {"Application/json"})
	public List<Product> getEmployeesByRange()
	{
				return service.getEmployeesByRange();
		
	}*/
	
	/*@ResponseStatus(value=HttpStatus.NOT_FOUND, reason="Employee Id does not exists")
	@ExceptionHandler({ProductExp.class})
	public void handleException()
	{
		
	}*/
	
	
	
	
}
