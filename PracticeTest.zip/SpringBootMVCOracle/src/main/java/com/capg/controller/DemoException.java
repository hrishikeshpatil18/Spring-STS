package com.capg.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

//import com.capg.beans.ErrorInfo;
import com.capg.exception.ProductExp;

@ControllerAdvice
public class DemoException 
{
	@ResponseBody
	@ResponseStatus(value=HttpStatus.NOT_FOUND, reason="No Products are available")
	@ExceptionHandler(value= {ProductExp.class})
	protected ProductExp handlerConflict (Exception ex, HttpServletRequest req)
	{
		String bodyofResponse = ex.getMessage();
		String uri = req.getRequestURI().toString();
		return new ProductExp();
	}

}
