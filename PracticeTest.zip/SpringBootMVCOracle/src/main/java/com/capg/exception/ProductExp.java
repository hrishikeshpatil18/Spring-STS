package com.capg.exception;

public class ProductExp extends Exception 

{
	/*String bodyofResponse;
	String uri;*/
	


}
