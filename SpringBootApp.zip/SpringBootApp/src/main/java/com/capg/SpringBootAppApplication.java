package com.capg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class SpringBootAppApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext context = SpringApplication.run(SpringBootAppApplication.class, args);
	
		context.getBean(Employee.class);
		Employee emp=new Employee();
		emp.setEid(100);
		emp.setEname("Hrishi");
		emp.setSalary(25000);
		System.out.println(emp);
	
	
	}

}
