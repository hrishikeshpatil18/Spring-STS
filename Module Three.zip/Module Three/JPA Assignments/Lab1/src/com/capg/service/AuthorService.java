package com.capg.service;

import com.capg.entities.Author;

public interface AuthorService {
	
	public void addAuthor(Author a);
	public void removeAuthor(int a);
	public void updateAuthor(Author a);
	public Author findAuthor(int aid);
	
}
